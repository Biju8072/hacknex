# VisionDetect - AI-Powered Object Detection Web Application

A modern, high-performance web application for real-time computer vision and object detection in images and videos.

Built exactly to match the **VisionDetect** user interface specifications.

---

## 🌟 Features

- **Pixel-Accurate UI Design**:
  - Gradient brand typography and custom SVG eye logo.
  - Dual upload cards for **Upload Image** and **Upload Video** with hover lift and glowing active indicators.
  - Floating 3D artwork scene with camera viewfinder framing brackets and ambient glow.
  - Bottom 4-feature bar: Fast & Accurate, Multiple Object Detection, AI Powered, Easy to Use.
- **In-Browser Object Detection**:
  - Powered by **TensorFlow.js** and **COCO-SSD** model running directly on client hardware (zero server upload required).
  - Detects 80+ common object categories (people, vehicles, animals, electronics, accessories, etc.).
- **Interactive AI Studio Workspace**:
  - Canvas drawing with futuristic neon bounding boxes, class labels, and confidence tags.
  - Real-time sensitivity threshold slider (10% to 95%).
  - Real-time object category tally chips (e.g. `🚶 Person × 7`, `🚗 Car × 2`, `🚲 Bicycle × 1`).
  - Detection breakdown table with confidence progress bars.
  - Annotated Image PNG download and JSON inspection export.
- **Video & Webcam Support**:
  - Upload MP4/WebM videos or switch directly to live Webcam mode for real-time video detection with an FPS counter.

---

## 🚀 Getting Started

To launch the local web server:

```bash
cd /Users/apple/Documents/vision-detect
python3 -m http.server 3000
```

Open your browser and navigate to:
[http://localhost:3000](http://localhost:3000)

---

## 📂 Project Structure

```
vision-detect/
├── index.html        # Main HTML markup with hero layout, navbar, modals, and studio
├── style.css         # Complete vanilla CSS design system, typography, animations
├── app.js            # TensorFlow COCO-SSD integration, canvas drawing, UI state
├── assets/           # High-resolution sample images for instant demonstrations
│   ├── street_sample.jpg
│   └── room_sample.jpg
└── README.md         # Project documentation
```
